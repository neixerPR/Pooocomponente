// Práctica 3: cálculo de apoyo visual. El servidor siempre valida y recalcula.
(() => {
  'use strict';
  const form = document.getElementById('documento-form');
  if (!form) return;
  const tbody = document.getElementById('filas-detalle');
  const management = form.querySelector('input[name="lineas-TOTAL_FORMS"]');
  const add = document.getElementById('agregar-fila');
  const preview = document.getElementById('total-estimado');
  const pricesNode = document.getElementById('precios-productos');
  const precios = pricesNode ? JSON.parse(pricesNode.textContent) : {};
  const esVenta = form.dataset.tipo === 'venta';
  const money = (number) => '$ ' + number.toFixed(2);
  const decimal = (value) => {
    const num = Number(String(value || '').replace(',', '.'));
    return Number.isFinite(num) && num > 0 ? num : 0;
  };

  function recalcular() {
    let total = 0;
    tbody.querySelectorAll('tr.fila-detalle').forEach((row) => {
      if (row.querySelector('input[name$="-DELETE"]')?.checked) return;
      const id = row.querySelector('.js-producto')?.value;
      const cantidad = decimal(row.querySelector('.js-cantidad')?.value);
      const precio = decimal(row.querySelector('.js-precio')?.value);
      const subtotal = id ? Math.round((cantidad * precio + Number.EPSILON) * 100) / 100 : 0;
      row.querySelector('.subtotal-fila').textContent = money(subtotal);
      total += subtotal;
    });
    preview.textContent = money(total);
  }

  tbody.addEventListener('change', (event) => {
    if (event.target.matches('.js-producto') && esVenta) {
      const row = event.target.closest('tr');
      const priceField = row.querySelector('.js-precio');
      if (event.target.value && Object.prototype.hasOwnProperty.call(precios, event.target.value)) {
        priceField.value = precios[event.target.value];
      }
    }
    recalcular();
  });
  tbody.addEventListener('input', recalcular);
  tbody.addEventListener('click', (event) => {
    const button = event.target.closest('.btn-quitar');
    if (!button) return;
    const row = button.closest('tr');
    const deletion = row.querySelector('input[name$="-DELETE"]');
    if (deletion) deletion.checked = true;
    row.classList.add('d-none');
    recalcular();
  });
  add.addEventListener('click', () => {
    const index = Number(management.value);
    const html = document.getElementById('plantilla-fila').innerHTML.replace(/__prefix__/g, String(index));
    tbody.insertAdjacentHTML('beforeend', html);
    management.value = String(index + 1);
    recalcular();
  });
  recalcular();
})();
