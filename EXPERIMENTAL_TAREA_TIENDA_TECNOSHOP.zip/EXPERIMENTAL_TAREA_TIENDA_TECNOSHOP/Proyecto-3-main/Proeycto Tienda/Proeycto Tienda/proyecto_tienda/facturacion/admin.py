from django.contrib import admin
from .models import Categoria, Marca, Producto, Cliente, Perfil, Proveedor, Venta, DetalleVenta, Compra, DetalleCompra

admin.site.register(Categoria)
admin.site.register(Marca)
admin.site.register(Cliente)
admin.site.register(Perfil)


@admin.register(Producto)
class ProductoAdmin(admin.ModelAdmin):
    list_display = ("nombre", "marca", "precio", "stock", "activo")
    search_fields = ("nombre",)
    list_filter = ("marca", "categorias", "activo")
    filter_horizontal = ("categorias",)


@admin.register(Proveedor)
class ProveedorAdmin(admin.ModelAdmin):
    list_display = ("razon_social", "identificacion", "telefono", "activo")
    search_fields = ("razon_social", "identificacion")


class DetalleVentaInline(admin.TabularInline):
    model = DetalleVenta
    extra = 0
    readonly_fields = ("producto", "cantidad", "precio_unitario", "subtotal")
    can_delete = False

    def has_add_permission(self, request, obj=None):
        return False


class DetalleCompraInline(admin.TabularInline):
    model = DetalleCompra
    extra = 0
    readonly_fields = ("producto", "cantidad", "costo_unitario", "subtotal")
    can_delete = False

    def has_add_permission(self, request, obj=None):
        return False


@admin.register(Venta)
class VentaAdmin(admin.ModelAdmin):
    list_display = ("id", "cliente", "fecha", "total", "estado")
    readonly_fields = ("cliente", "fecha", "total", "estado", "usuario", "observacion")
    inlines = [DetalleVentaInline]

    def has_add_permission(self, request):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(Compra)
class CompraAdmin(admin.ModelAdmin):
    list_display = ("id", "proveedor", "fecha", "total", "estado")
    readonly_fields = ("proveedor", "fecha", "total", "estado", "usuario", "observacion")
    inlines = [DetalleCompraInline]

    def has_add_permission(self, request):
        return False

    def has_delete_permission(self, request, obj=None):
        return False
