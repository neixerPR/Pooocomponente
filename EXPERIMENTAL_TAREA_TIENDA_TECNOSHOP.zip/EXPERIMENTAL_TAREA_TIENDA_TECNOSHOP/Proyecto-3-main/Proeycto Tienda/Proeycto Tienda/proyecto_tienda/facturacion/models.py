from django.contrib.auth.models import User
from django.db import models


class Categoria(models.Model):
    nombre = models.CharField(max_length=60, unique=True)
    descripcion = models.TextField(blank=True)
    activo = models.BooleanField(default=True)

    class Meta:
        verbose_name = "Categoría"
        verbose_name_plural = "Categorías"
        ordering = ["nombre"]

    def __str__(self):
        return self.nombre


class Marca(models.Model):
    # Lado "1" de la relación 1:N con Producto
    nombre = models.CharField(max_length=60, unique=True)
    pais_origen = models.CharField("País de origen", max_length=60, blank=True)
    activo = models.BooleanField(default=True)

    class Meta:
        verbose_name = "Marca"
        verbose_name_plural = "Marcas"
        ordering = ["nombre"]

    def __str__(self):
        return self.nombre


class Producto(models.Model):
    nombre = models.CharField(max_length=100)
    descripcion = models.TextField("Descripción", blank=True)
    precio = models.DecimalField(max_digits=10, decimal_places=2)
    stock = models.PositiveIntegerField(default=0)
    # 1:N → una marca tiene muchos productos
    marca = models.ForeignKey(Marca, on_delete=models.PROTECT, related_name="productos")
    # N:M → un producto en varias categorías
    categorias = models.ManyToManyField(Categoria, related_name="productos", blank=True)
    activo = models.BooleanField(default=True)
    fecha_creacion = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Producto"
        verbose_name_plural = "Productos"
        ordering = ["nombre"]

    def __str__(self):
        return f"{self.nombre} ({self.marca})"


class Cliente(models.Model):
    cedula = models.CharField("Cédula", max_length=10, unique=True)
    nombres = models.CharField(max_length=80)
    apellidos = models.CharField(max_length=80)
    email = models.EmailField("Correo", blank=True)
    telefono = models.CharField("Teléfono", max_length=15, blank=True)
    direccion = models.CharField("Dirección", max_length=200, blank=True)
    fecha_registro = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Cliente"
        verbose_name_plural = "Clientes"
        ordering = ["apellidos", "nombres"]

    def __str__(self):
        return f"{self.apellidos} {self.nombres}"


class Perfil(models.Model):
    # 1:1 con el User de Django
    usuario = models.OneToOneField(User, on_delete=models.CASCADE, related_name="perfil")
    cedula = models.CharField("Cédula", max_length=10, blank=True)
    telefono = models.CharField("Teléfono", max_length=15, blank=True)
    direccion = models.CharField("Dirección", max_length=200, blank=True)
    cargo = models.CharField(max_length=50, blank=True)

    class Meta:
        verbose_name = "Perfil"
        verbose_name_plural = "Perfiles"

    def __str__(self):
        return f"Perfil de {self.usuario.username}"


# ---------- PRÁCTICA 3: proveedores, ventas y compras ----------
# Los cinco modelos de la Tarea 2 no se reemplazan: se amplían sus relaciones.
class Proveedor(models.Model):
    identificacion = models.CharField("RUC o identificación", max_length=13, unique=True)
    razon_social = models.CharField("Razón social", max_length=120)
    contacto = models.CharField("Persona de contacto", max_length=100, blank=True)
    telefono = models.CharField("Teléfono", max_length=15, blank=True)
    email = models.EmailField("Correo", blank=True)
    direccion = models.CharField("Dirección", max_length=200, blank=True)
    activo = models.BooleanField(default=True)

    class Meta:
        verbose_name = "Proveedor"
        verbose_name_plural = "Proveedores"
        ordering = ["razon_social"]

    def __str__(self):
        return self.razon_social


class Venta(models.Model):
    class Estado(models.TextChoices):
        REGISTRADA = "REGISTRADA", "Registrada"
        ANULADA = "ANULADA", "Anulada"

    cliente = models.ForeignKey(Cliente, on_delete=models.PROTECT, related_name="ventas")
    fecha = models.DateTimeField(auto_now_add=True)
    total = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    estado = models.CharField(max_length=12, choices=Estado.choices, default=Estado.REGISTRADA)
    usuario = models.ForeignKey(User, on_delete=models.SET_NULL, related_name="ventas", null=True, blank=True)
    observacion = models.CharField("Observación", max_length=200, blank=True)

    class Meta:
        verbose_name = "Venta"
        verbose_name_plural = "Ventas"
        ordering = ["-fecha", "-pk"]
        constraints = [models.CheckConstraint(condition=models.Q(total__gte=0), name="venta_total_no_negativo")]

    def __str__(self):
        return f"Venta #{self.pk or 'nueva'} - {self.cliente}"


class DetalleVenta(models.Model):
    venta = models.ForeignKey(Venta, on_delete=models.CASCADE, related_name="detalles")
    producto = models.ForeignKey(Producto, on_delete=models.PROTECT, related_name="detalles_venta")
    cantidad = models.PositiveIntegerField()
    precio_unitario = models.DecimalField(max_digits=10, decimal_places=2)
    subtotal = models.DecimalField(max_digits=12, decimal_places=2)

    class Meta:
        verbose_name = "Detalle de venta"
        verbose_name_plural = "Detalles de venta"
        constraints = [
            models.UniqueConstraint(fields=["venta", "producto"], name="venta_producto_unico"),
            models.CheckConstraint(condition=models.Q(cantidad__gt=0), name="dv_cantidad_positiva"),
            models.CheckConstraint(condition=models.Q(precio_unitario__gt=0), name="dv_precio_positivo"),
            models.CheckConstraint(condition=models.Q(subtotal__gte=0), name="dv_subtotal_no_negativo"),
        ]

    def __str__(self):
        return f"{self.producto.nombre} × {self.cantidad}"


class Compra(models.Model):
    class Estado(models.TextChoices):
        REGISTRADA = "REGISTRADA", "Registrada"
        ANULADA = "ANULADA", "Anulada"

    proveedor = models.ForeignKey(Proveedor, on_delete=models.PROTECT, related_name="compras")
    fecha = models.DateTimeField(auto_now_add=True)
    total = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    estado = models.CharField(max_length=12, choices=Estado.choices, default=Estado.REGISTRADA)
    usuario = models.ForeignKey(User, on_delete=models.SET_NULL, related_name="compras", null=True, blank=True)
    observacion = models.CharField("Observación", max_length=200, blank=True)

    class Meta:
        verbose_name = "Compra"
        verbose_name_plural = "Compras"
        ordering = ["-fecha", "-pk"]
        constraints = [models.CheckConstraint(condition=models.Q(total__gte=0), name="compra_total_no_negativo")]

    def __str__(self):
        return f"Compra #{self.pk or 'nueva'} - {self.proveedor}"


class DetalleCompra(models.Model):
    compra = models.ForeignKey(Compra, on_delete=models.CASCADE, related_name="detalles")
    producto = models.ForeignKey(Producto, on_delete=models.PROTECT, related_name="detalles_compra")
    cantidad = models.PositiveIntegerField()
    costo_unitario = models.DecimalField(max_digits=10, decimal_places=2)
    subtotal = models.DecimalField(max_digits=12, decimal_places=2)

    class Meta:
        verbose_name = "Detalle de compra"
        verbose_name_plural = "Detalles de compra"
        constraints = [
            models.UniqueConstraint(fields=["compra", "producto"], name="compra_producto_unico"),
            models.CheckConstraint(condition=models.Q(cantidad__gt=0), name="dc_cantidad_positiva"),
            models.CheckConstraint(condition=models.Q(costo_unitario__gt=0), name="dc_costo_positivo"),
            models.CheckConstraint(condition=models.Q(subtotal__gte=0), name="dc_subtotal_no_negativo"),
        ]

    def __str__(self):
        return f"{self.producto.nombre} × {self.cantidad}"
