"""Operaciones de negocio de la Práctica 3.

En cada venta/compra: validar primero, guardar cabecera y detalles juntos,
actualizar existencias, y deshacer TODOS los cambios si ocurre un error.
"""
from decimal import Decimal

from django.core.exceptions import ValidationError
from django.db import transaction
from django.db.models import F

from .models import Compra, Producto, Venta


CERO = Decimal("0.00")


def _lineas_validas(formset):
    # Formsets ya comprobados con .is_valid() por la vista.
    return [
        f.cleaned_data for f in formset.forms
        if f.cleaned_data and not f.cleaned_data.get("DELETE") and f.cleaned_data.get("producto")
    ]


@transaction.atomic
def registrar_venta(form, formset, usuario):
    """Descuenta stock de forma condicional, sin permitir inventarios negativos."""
    if not (form.is_valid() and formset.is_valid()):
        raise ValidationError("Los datos de venta deben validarse antes de guardar.")
    lineas = _lineas_validas(formset)
    if not lineas:
        raise ValidationError("Debe existir al menos un detalle.")

    # Validar TODAS las líneas antes de crear el documento.
    for linea in lineas:
        producto = Producto.objects.get(pk=linea["producto"].pk)
        if not producto.activo:
            raise ValidationError(f"El producto «{producto.nombre}» está inactivo.")
        if producto.stock < linea["cantidad"]:
            raise ValidationError(f"Stock insuficiente para «{producto.nombre}»: quedan {producto.stock} unidades.")

    venta = form.save(commit=False)
    venta.usuario = usuario
    venta.total = CERO
    venta.save()
    total = CERO
    for linea in lineas:
        producto = linea["producto"]
        cantidad = linea["cantidad"]
        # Condición del UPDATE: incluso si el inventario cambió, nunca queda negativo.
        actualizados = Producto.objects.filter(pk=producto.pk, activo=True, stock__gte=cantidad).update(
            stock=F("stock") - cantidad
        )
        if actualizados != 1:
            raise ValidationError(f"No se pudo reservar stock para «{producto.nombre}».")
        subtotal = linea["precio_unitario"] * cantidad
        venta.detalles.create(
            producto=producto, cantidad=cantidad,
            precio_unitario=linea["precio_unitario"], subtotal=subtotal,
        )
        total += subtotal
    venta.total = total
    venta.save(update_fields=["total"])
    return venta


@transaction.atomic
def registrar_compra(form, formset, usuario):
    """Registra compra completa y suma existencias en una sola transacción."""
    if not (form.is_valid() and formset.is_valid()):
        raise ValidationError("Los datos de compra deben validarse antes de guardar.")
    lineas = _lineas_validas(formset)
    if not lineas:
        raise ValidationError("Debe existir al menos un detalle.")
    for linea in lineas:
        if not Producto.objects.filter(pk=linea["producto"].pk, activo=True).exists():
            raise ValidationError("No puedes comprar un producto inactivo.")
    compra = form.save(commit=False)
    compra.usuario = usuario
    compra.total = CERO
    compra.save()
    total = CERO
    for linea in lineas:
        cantidad = linea["cantidad"]
        costo = linea["costo_unitario"]
        subtotal = costo * cantidad
        producto = linea["producto"]
        compra.detalles.create(producto=producto, cantidad=cantidad, costo_unitario=costo, subtotal=subtotal)
        Producto.objects.filter(pk=producto.pk, activo=True).update(stock=F("stock") + cantidad)
        total += subtotal
    compra.total = total
    compra.save(update_fields=["total"])
    return compra


@transaction.atomic
def anular_venta(venta_id):
    """Mantiene historial y devuelve las unidades; no borra facturas."""
    venta = Venta.objects.select_for_update().get(pk=venta_id)
    if venta.estado == Venta.Estado.ANULADA:
        raise ValidationError("Esta venta ya fue anulada.")
    for detalle in venta.detalles.all():
        Producto.objects.filter(pk=detalle.producto_id).update(stock=F("stock") + detalle.cantidad)
    venta.estado = Venta.Estado.ANULADA
    venta.save(update_fields=["estado"])
    return venta


@transaction.atomic
def anular_compra(compra_id):
    """Reversa stock de la compra solo si hay unidades suficientes."""
    compra = Compra.objects.select_for_update().get(pk=compra_id)
    if compra.estado == Compra.Estado.ANULADA:
        raise ValidationError("Esta compra ya fue anulada.")
    # Validar existencia de TODOS los productos antes de descontar alguno.
    for detalle in compra.detalles.all():
        producto = Producto.objects.get(pk=detalle.producto_id)
        if producto.stock < detalle.cantidad:
            raise ValidationError(
                f"No se puede anular: «{producto.nombre}» tiene {producto.stock} unidades, "
                f"pero se necesitan {detalle.cantidad}."
            )
    for detalle in compra.detalles.all():
        modificados = Producto.objects.filter(pk=detalle.producto_id, stock__gte=detalle.cantidad).update(
            stock=F("stock") - detalle.cantidad
        )
        if modificados != 1:
            raise ValidationError("El stock cambió durante la anulación; no se modificó el documento.")
    compra.estado = Compra.Estado.ANULADA
    compra.save(update_fields=["estado"])
    return compra
