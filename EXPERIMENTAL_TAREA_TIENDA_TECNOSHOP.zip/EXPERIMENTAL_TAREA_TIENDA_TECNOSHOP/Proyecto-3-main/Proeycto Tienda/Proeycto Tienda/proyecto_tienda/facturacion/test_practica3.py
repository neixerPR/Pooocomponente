"""Pruebas nuevas: conservar tests.py original (27 casos) y añadir verificación del módulo 3."""
from decimal import Decimal

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from .forms import ProveedorForm
from .models import (Categoria, Cliente, Compra, DetalleCompra, DetalleVenta,
                     Marca, Producto, Proveedor, Venta)


class PruebaPractica3(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.usuario = get_user_model().objects.create_user("operador", password="ClaveTest123!")
        cls.marca = Marca.objects.create(nombre="Marca Q")
        cls.categoria = Categoria.objects.create(nombre="Electrónica")
        cls.producto = Producto.objects.create(nombre="Teclado", marca=cls.marca, precio=Decimal("12.25"), stock=5)
        cls.producto.categorias.add(cls.categoria)
        cls.segundo = Producto.objects.create(nombre="Ratón", marca=cls.marca, precio=Decimal("8.50"), stock=2)
        cls.cliente = Cliente.objects.create(cedula="0990001112", nombres="Ana", apellidos="Pérez")
        cls.proveedor = Proveedor.objects.create(identificacion="0991112223001", razon_social="Distribuidora Prueba", activo=True)

    def setUp(self):
        self.client.force_login(self.usuario)

    def venta_data(self, producto=None, cantidad=2, precio="12.25", **campos):
        datos = {
            "cliente": str(self.cliente.pk), "observacion": "Venta de prueba",
            "lineas-TOTAL_FORMS": "2", "lineas-INITIAL_FORMS": "0",
            "lineas-MIN_NUM_FORMS": "1", "lineas-MAX_NUM_FORMS": "1000",
            "lineas-0-producto": str((producto or self.producto).pk),
            "lineas-0-cantidad": str(cantidad),
            "lineas-0-precio_unitario": str(precio),
        }
        return {**datos, **campos}

    def compra_data(self, cantidad=3, costo="7.10", **campos):
        datos = {
            "proveedor": str(self.proveedor.pk), "observacion": "Compra de prueba",
            "lineas-TOTAL_FORMS": "2", "lineas-INITIAL_FORMS": "0",
            "lineas-MIN_NUM_FORMS": "1", "lineas-MAX_NUM_FORMS": "1000",
            "lineas-0-producto": str(self.producto.pk),
            "lineas-0-cantidad": str(cantidad),
            "lineas-0-costo_unitario": str(costo),
        }
        return {**datos, **campos}

    def test_nuevas_urls_solo_con_login(self):
        self.client.logout()
        rutas = [
            ("proveedor_lista", []), ("proveedor_crear", []),
            ("proveedor_editar", [self.proveedor.pk]), ("proveedor_eliminar", [self.proveedor.pk]),
            ("venta_lista", []), ("venta_crear", []), ("compra_lista", []), ("compra_crear", []),
        ]
        for ruta, args in rutas:
            with self.subTest(ruta=ruta):
                self.assertEqual(self.client.get(reverse("facturacion:" + ruta, args=args)).status_code, 302)

    def test_proveedor_crear(self):
        respuesta = self.client.post(reverse("facturacion:proveedor_crear"), {
            "identificacion": "0999999999001", "razon_social": " Nueva Distribuidora ", "contacto": "Juan", "activo": "on"
        })
        self.assertRedirects(respuesta, reverse("facturacion:proveedor_lista"))
        self.assertTrue(Proveedor.objects.filter(razon_social="Nueva Distribuidora").exists())

    def test_proveedor_form_no_acepta_identificacion_incorrecta(self):
        for iden in ("abc", "09988", "１２３４５６７８９０"):
            with self.subTest(iden=iden):
                f = ProveedorForm({"identificacion": iden, "razon_social": "Prueba Valida"})
                self.assertFalse(f.is_valid())
                self.assertIn("identificacion", f.errors)

    def test_proveedor_duplicado(self):
        f = ProveedorForm({"identificacion": self.proveedor.identificacion, "razon_social": "Otro"})
        self.assertFalse(f.is_valid())
        self.assertIn("identificacion", f.errors)

    def test_proveedor_editar(self):
        r = self.client.post(reverse("facturacion:proveedor_editar", args=[self.proveedor.pk]), {
            "identificacion": self.proveedor.identificacion, "razon_social": "Otra razón social", "activo": "on"
        })
        self.assertEqual(r.status_code, 302)
        self.proveedor.refresh_from_db()
        self.assertEqual(self.proveedor.razon_social, "Otra razón social")

    def test_proveedor_eliminar_solo_por_post(self):
        url = reverse("facturacion:proveedor_eliminar", args=[self.proveedor.pk])
        self.assertEqual(self.client.get(url).status_code, 200)
        self.assertTrue(Proveedor.objects.filter(pk=self.proveedor.pk).exists())
        self.assertEqual(self.client.post(url).status_code, 302)
        self.assertFalse(Proveedor.objects.filter(pk=self.proveedor.pk).exists())

    def test_proveedor_busqueda(self):
        r = self.client.get(reverse("facturacion:proveedor_lista"), {"q": "Distribuidora"})
        self.assertContains(r, "Distribuidora Prueba")

    def test_get_formularios_de_documentos(self):
        for ruta in ("venta_crear", "compra_crear"):
            with self.subTest(ruta=ruta):
                r = self.client.get(reverse("facturacion:" + ruta))
                self.assertEqual(r.status_code, 200)
                self.assertContains(r, "lineas-TOTAL_FORMS")
                self.assertContains(r, "agregar-fila")

    def test_venta_crea_detalle_calcula_total_y_descontar_stock(self):
        r = self.client.post(reverse("facturacion:venta_crear"), self.venta_data(), follow=True)
        self.assertEqual(r.status_code, 200)
        self.assertEqual(Venta.objects.count(), 1)
        venta = Venta.objects.get()
        self.assertEqual(venta.total, Decimal("24.50"))
        self.assertEqual(venta.usuario, self.usuario)
        self.assertEqual(venta.detalles.count(), 1)
        det = venta.detalles.get()
        self.assertEqual(det.precio_unitario, Decimal("12.25"))
        self.assertEqual(det.subtotal, Decimal("24.50"))
        self.producto.refresh_from_db()
        self.assertEqual(self.producto.stock, 3)
        self.assertContains(r, "Venta #")

    def test_venta_dos_productos_suma_importes(self):
        datos = self.venta_data(**{
            "lineas-1-producto": str(self.segundo.pk), "lineas-1-cantidad": "1", "lineas-1-precio_unitario": "8.50"
        })
        r = self.client.post(reverse("facturacion:venta_crear"), datos)
        self.assertEqual(r.status_code, 302)
        self.assertEqual(Venta.objects.get().total, Decimal("33.00"))
        self.assertEqual(DetalleVenta.objects.count(), 2)
        self.producto.refresh_from_db()
        self.segundo.refresh_from_db()
        self.assertEqual(self.producto.stock, 3)
        self.assertEqual(self.segundo.stock, 1)

    def test_stock_insuficiente_no_crea_documento(self):
        r = self.client.post(reverse("facturacion:venta_crear"), self.venta_data(cantidad=100))
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "Stock insuficiente")
        self.assertFalse(Venta.objects.exists())
        self.producto.refresh_from_db()
        self.assertEqual(self.producto.stock, 5)

    def test_no_registra_venta_sin_detalles(self):
        datos = self.venta_data()
        datos["lineas-0-producto"] = ""
        datos["lineas-0-cantidad"] = ""
        datos["lineas-0-precio_unitario"] = ""
        self.assertEqual(self.client.post(reverse("facturacion:venta_crear"), datos).status_code, 200)
        self.assertFalse(Venta.objects.exists())

    def test_cantidad_negativa_rechazada(self):
        r = self.client.post(reverse("facturacion:venta_crear"), self.venta_data(cantidad=-1))
        self.assertEqual(r.status_code, 200)
        self.assertFalse(Venta.objects.exists())

    def test_precio_cero_rechazado(self):
        r = self.client.post(reverse("facturacion:venta_crear"), self.venta_data(precio="0.00"))
        self.assertEqual(r.status_code, 200)
        self.assertFalse(Venta.objects.exists())

    def test_productos_duplicados_rechazados(self):
        datos = self.venta_data(**{
            "lineas-1-producto": str(self.producto.pk), "lineas-1-cantidad": "1", "lineas-1-precio_unitario": "12.25"
        })
        r = self.client.post(reverse("facturacion:venta_crear"), datos)
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "No repitas el mismo producto")
        self.assertFalse(Venta.objects.exists())

    def test_compra_suma_stock_y_total(self):
        r = self.client.post(reverse("facturacion:compra_crear"), self.compra_data())
        self.assertEqual(r.status_code, 302)
        compra = Compra.objects.get()
        self.assertEqual(compra.total, Decimal("21.30"))
        det = DetalleCompra.objects.get()
        self.assertEqual(det.subtotal, Decimal("21.30"))
        self.producto.refresh_from_db()
        self.assertEqual(self.producto.stock, 8)

    def test_compra_dos_productos(self):
        datos = self.compra_data(**{
            "lineas-1-producto": str(self.segundo.pk), "lineas-1-cantidad": "2", "lineas-1-costo_unitario": "4.05"
        })
        r = self.client.post(reverse("facturacion:compra_crear"), datos)
        self.assertEqual(r.status_code, 302)
        self.assertEqual(Compra.objects.get().total, Decimal("29.40"))
        self.segundo.refresh_from_db()
        self.assertEqual(self.segundo.stock, 4)

    def test_compra_costo_cero_rechazado(self):
        r = self.client.post(reverse("facturacion:compra_crear"), self.compra_data(costo="0.00"))
        self.assertEqual(r.status_code, 200)
        self.assertFalse(Compra.objects.exists())

    def test_compra_proveedor_inactivo_rechazado(self):
        self.proveedor.activo = False
        self.proveedor.save()
        r = self.client.post(reverse("facturacion:compra_crear"), self.compra_data())
        self.assertEqual(r.status_code, 200)
        self.assertFalse(Compra.objects.exists())

    def test_compra_duplicados_rechazados(self):
        datos = self.compra_data(**{
            "lineas-1-producto": str(self.producto.pk), "lineas-1-cantidad": "1", "lineas-1-costo_unitario": "2.00"
        })
        r = self.client.post(reverse("facturacion:compra_crear"), datos)
        self.assertEqual(r.status_code, 200)
        self.assertFalse(Compra.objects.exists())

    def test_anular_venta_regresa_stock_y_preserva_historial(self):
        self.client.post(reverse("facturacion:venta_crear"), self.venta_data())
        venta = Venta.objects.get()
        url = reverse("facturacion:venta_anular", args=[venta.pk])
        self.assertEqual(self.client.get(url).status_code, 200)
        self.assertEqual(Venta.objects.get().estado, Venta.Estado.REGISTRADA)
        r = self.client.post(url)
        self.assertEqual(r.status_code, 302)
        venta.refresh_from_db()
        self.assertEqual(venta.estado, Venta.Estado.ANULADA)
        self.assertEqual(venta.detalles.count(), 1)
        self.producto.refresh_from_db()
        self.assertEqual(self.producto.stock, 5)

    def test_segunda_anulacion_no_duplica_stock(self):
        self.client.post(reverse("facturacion:venta_crear"), self.venta_data())
        venta = Venta.objects.get()
        url = reverse("facturacion:venta_anular", args=[venta.pk])
        self.client.post(url)
        self.client.post(url)
        self.producto.refresh_from_db()
        self.assertEqual(self.producto.stock, 5)

    def test_anular_compra_descontar_stock(self):
        self.client.post(reverse("facturacion:compra_crear"), self.compra_data())
        compra = Compra.objects.get()
        self.assertEqual(self.client.post(reverse("facturacion:compra_anular", args=[compra.pk])).status_code, 302)
        compra.refresh_from_db()
        self.assertEqual(compra.estado, Compra.Estado.ANULADA)
        self.producto.refresh_from_db()
        self.assertEqual(self.producto.stock, 5)

    def test_anular_compra_con_stock_insuficiente_no_modifica_nada(self):
        self.client.post(reverse("facturacion:compra_crear"), self.compra_data(cantidad=3))
        compra = Compra.objects.get()
        self.client.post(reverse("facturacion:venta_crear"), self.venta_data(cantidad=7))
        self.producto.refresh_from_db()
        self.assertEqual(self.producto.stock, 1)
        r = self.client.post(reverse("facturacion:compra_anular", args=[compra.pk]), follow=True)
        self.assertContains(r, "No se puede anular")
        compra.refresh_from_db()
        self.assertEqual(compra.estado, Compra.Estado.REGISTRADA)
        self.producto.refresh_from_db()
        self.assertEqual(self.producto.stock, 1)

    def test_no_se_pueden_borrar_clientes_productos_y_proveedores_con_movimientos(self):
        self.client.post(reverse("facturacion:venta_crear"), self.venta_data())
        self.client.post(reverse("facturacion:compra_crear"), self.compra_data())
        urls = [
            ("cliente_eliminar", self.cliente.pk),
            ("producto_eliminar", self.producto.pk),
            ("proveedor_eliminar", self.proveedor.pk),
        ]
        for nombre, pk in urls:
            with self.subTest(nombre=nombre):
                r = self.client.post(reverse("facturacion:" + nombre, args=[pk]))
                self.assertEqual(r.status_code, 302)
        self.assertTrue(Cliente.objects.filter(pk=self.cliente.pk).exists())
        self.assertTrue(Producto.objects.filter(pk=self.producto.pk).exists())
        self.assertTrue(Proveedor.objects.filter(pk=self.proveedor.pk).exists())

    def test_venta_y_compra_listas_y_detalles(self):
        self.client.post(reverse("facturacion:venta_crear"), self.venta_data())
        self.client.post(reverse("facturacion:compra_crear"), self.compra_data())
        venta = Venta.objects.get()
        compra = Compra.objects.get()
        for ruta in ("venta_lista", "compra_lista"):
            self.assertEqual(self.client.get(reverse("facturacion:" + ruta)).status_code, 200)
        self.assertContains(self.client.get(reverse("facturacion:venta_detalle", args=[venta.pk])), "24,50")
        self.assertContains(self.client.get(reverse("facturacion:compra_detalle", args=[compra.pk])), "21,30")

    def test_producto_inactivo_no_se_vende_ni_compra(self):
        self.producto.activo = False
        self.producto.save()
        self.assertEqual(self.client.post(reverse("facturacion:venta_crear"), self.venta_data()).status_code, 200)
        self.assertEqual(self.client.post(reverse("facturacion:compra_crear"), self.compra_data()).status_code, 200)
        self.assertFalse(Venta.objects.exists())
        self.assertFalse(Compra.objects.exists())

    def test_total_demasiado_grande_se_rechaza(self):
        datos = self.venta_data(precio="99999999.99", cantidad=200)
        r = self.client.post(reverse("facturacion:venta_crear"), datos)
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "límite permitido")
        self.assertFalse(Venta.objects.exists())

    def test_linea_eliminada_no_se_guarda(self):
        datos = self.venta_data(**{
            "lineas-0-DELETE": "on",
            "lineas-1-producto": str(self.segundo.pk),
            "lineas-1-cantidad": "1", "lineas-1-precio_unitario": "8.50",
        })
        r = self.client.post(reverse("facturacion:venta_crear"), datos)
        self.assertEqual(r.status_code, 302)
        self.assertEqual(DetalleVenta.objects.count(), 1)
        self.assertEqual(Venta.objects.get().total, Decimal("8.50"))
        self.producto.refresh_from_db()
        self.assertEqual(self.producto.stock, 5)

    def test_compras_y_ventas_no_crean_documentos_con_formsets_incorrectos(self):
        for nombre, datos in (("venta_crear", self.venta_data()), ("compra_crear", self.compra_data())):
            with self.subTest(nombre=nombre):
                datos.pop("lineas-TOTAL_FORMS")
                r = self.client.post(reverse("facturacion:" + nombre), datos)
                self.assertEqual(r.status_code, 200)
        self.assertFalse(Venta.objects.exists())
        self.assertFalse(Compra.objects.exists())

    def test_precios_monetarios_2_decimales(self):
        r = self.client.post(reverse("facturacion:venta_crear"), self.venta_data(precio="3.333"))
        self.assertEqual(r.status_code, 200)
        self.assertFalse(Venta.objects.exists())

    def test_venta_precio_historico_no_cambia_al_editar_producto(self):
        self.client.post(reverse("facturacion:venta_crear"), self.venta_data())
        self.producto.precio = Decimal("35.00")
        self.producto.save(update_fields=["precio"])
        venta = Venta.objects.get()
        self.assertEqual(venta.total, Decimal("24.50"))
        self.assertEqual(venta.detalles.get().precio_unitario, Decimal("12.25"))
