from decimal import Decimal
from django import forms
from django.db.models import Q
from .models import Categoria, Cliente, Marca, Perfil, Producto


class MarcaForm(forms.ModelForm):
    class Meta:
        model = Marca
        fields = ["nombre", "pais_origen", "activo"]
        labels = {"nombre": "Nombre de la marca"}
        widgets = {
            "nombre": forms.TextInput(attrs={"class": "form-control", "placeholder": "Ej: Samsung"}),
            "pais_origen": forms.TextInput(attrs={"class": "form-control", "placeholder": "Ej: Corea del Sur"}),
            "activo": forms.CheckboxInput(attrs={"class": "form-check-input"}),
        }

    def clean_nombre(self):
        nombre = self.cleaned_data["nombre"].strip()
        if len(nombre) < 2:
            raise forms.ValidationError("El nombre debe tener al menos 2 letras.")
        return nombre.title()


class ProductoForm(forms.ModelForm):
    class Meta:
        model = Producto
        fields = ["nombre", "descripcion", "marca", "categorias", "precio", "stock", "activo"]
        widgets = {
            "nombre": forms.TextInput(attrs={"class": "form-control", "placeholder": "Ej: Laptop Pro 14"}),
            "descripcion": forms.Textarea(attrs={"class": "form-control", "rows": 3}),
            "marca": forms.Select(attrs={"class": "form-select"}),
            "categorias": forms.CheckboxSelectMultiple(attrs={"class": "form-check-input"}),
            "precio": forms.NumberInput(attrs={"class": "form-control", "step": "0.01", "min": "0"}),
            "stock": forms.NumberInput(attrs={"class": "form-control", "min": "0"}),
            "activo": forms.CheckboxInput(attrs={"class": "form-check-input"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Al editar, conservar la marca actual aunque se haya desactivado.
        # De otro modo, un POST sin cambiar marca produce un falso error.
        marcas = Marca.objects.filter(activo=True)
        if self.instance.pk and self.instance.marca_id:
            marcas = Marca.objects.filter(Q(activo=True) | Q(pk=self.instance.marca_id))
        self.fields["marca"].queryset = marcas.distinct()
        self.fields["marca"].empty_label = "— Elige una marca —"

    def clean_precio(self):
        precio = self.cleaned_data["precio"]
        if precio <= 0:
            raise forms.ValidationError("El precio debe ser mayor que 0.")
        return precio


class CategoriaForm(forms.ModelForm):
    class Meta:
        model = Categoria
        fields = ["nombre", "descripcion", "activo"]
        widgets = {
            "nombre": forms.TextInput(attrs={"class": "form-control", "placeholder": "Ej: Laptops"}),
            "descripcion": forms.Textarea(attrs={"class": "form-control", "rows": 3,
                                                 "placeholder": "Descripción opcional"}),
            "activo": forms.CheckboxInput(attrs={"class": "form-check-input"}),
        }

    def clean_nombre(self):
        # Normaliza espacios y pone la primera letra en mayúscula.
        nombre = " ".join(self.cleaned_data["nombre"].split())
        if sum(letra.isalpha() for letra in nombre) < 3:
            raise forms.ValidationError("El nombre debe tener al menos 3 letras.")
        if not nombre[0].isalpha():
            raise forms.ValidationError("El nombre debe comenzar con una letra.")
        nombre = nombre[0].upper() + nombre[1:]
        # unique=True es sensible a mayúsculas en algunas BD; evita
        # categorías duplicadas con variantes OFERTAS / Ofertas.
        repetidas = Categoria.objects.filter(nombre__iexact=nombre)
        if self.instance.pk:
            repetidas = repetidas.exclude(pk=self.instance.pk)
        if repetidas.exists():
            raise forms.ValidationError("Ya existe una categoría con ese nombre.")
        return nombre


class ClienteForm(forms.ModelForm):
    class Meta:
        model = Cliente
        fields = ["cedula", "nombres", "apellidos", "email", "telefono", "direccion"]
        widgets = {
            "cedula": forms.TextInput(attrs={"class": "form-control", "placeholder": "10 dígitos", "maxlength": "10"}),
            "nombres": forms.TextInput(attrs={"class": "form-control"}),
            "apellidos": forms.TextInput(attrs={"class": "form-control"}),
            "email": forms.EmailInput(attrs={"class": "form-control", "placeholder": "correo@ejemplo.com"}),
            "telefono": forms.TextInput(attrs={"class": "form-control"}),
            "direccion": forms.TextInput(attrs={"class": "form-control"}),
        }

    def clean_cedula(self):
        # Exactamente 10 caracteres y solo números
        cedula = self.cleaned_data["cedula"].strip()
        if len(cedula) != 10:
            raise forms.ValidationError("La cédula debe tener exactamente 10 dígitos.")
        if not cedula.isascii() or not cedula.isdigit():
            raise forms.ValidationError("La cédula debe tener solo números.")
        return cedula


class PerfilForm(forms.ModelForm):
    # Sin 'usuario': siempre es request.user
    class Meta:
        model = Perfil
        fields = ["cedula", "telefono", "direccion", "cargo"]
        widgets = {
            "cedula": forms.TextInput(attrs={"class": "form-control", "maxlength": "10"}),
            "telefono": forms.TextInput(attrs={"class": "form-control"}),
            "direccion": forms.TextInput(attrs={"class": "form-control"}),
            "cargo": forms.TextInput(attrs={"class": "form-control", "placeholder": "Ej: Vendedor"}),
        }

    def clean_cedula(self):
        # El perfil admite cédula vacía; si se informa, debe tener 10 dígitos.
        cedula = self.cleaned_data["cedula"].strip()
        if cedula and (len(cedula) != 10 or not cedula.isascii() or not cedula.isdigit()):
            raise forms.ValidationError("La cédula debe tener exactamente 10 dígitos numéricos.")
        return cedula


# ---------- PRÁCTICA 3 ----------
from django.forms import BaseInlineFormSet, inlineformset_factory
from .models import Proveedor, Venta, DetalleVenta, Compra, DetalleCompra


class ProveedorForm(forms.ModelForm):
    class Meta:
        model = Proveedor
        fields = ["identificacion", "razon_social", "contacto", "telefono", "email", "direccion", "activo"]
        widgets = {
            "identificacion": forms.TextInput(attrs={"class": "form-control", "placeholder": "10 o 13 dígitos"}),
            "razon_social": forms.TextInput(attrs={"class": "form-control"}),
            "contacto": forms.TextInput(attrs={"class": "form-control"}),
            "telefono": forms.TextInput(attrs={"class": "form-control"}),
            "email": forms.EmailInput(attrs={"class": "form-control"}),
            "direccion": forms.TextInput(attrs={"class": "form-control"}),
            "activo": forms.CheckboxInput(attrs={"class": "form-check-input"}),
        }

    def clean_identificacion(self):
        identificacion = self.cleaned_data["identificacion"].strip()
        if len(identificacion) not in (10, 13) or not (identificacion.isascii() and identificacion.isdigit()):
            raise forms.ValidationError("La identificación debe tener 10 o 13 dígitos numéricos.")
        return identificacion

    def clean_razon_social(self):
        nombre = " ".join(self.cleaned_data["razon_social"].split())
        if len(nombre) < 3:
            raise forms.ValidationError("Escribe una razón social válida (mínimo 3 caracteres).")
        return nombre


class VentaForm(forms.ModelForm):
    class Meta:
        model = Venta
        fields = ["cliente", "observacion"]
        widgets = {
            "cliente": forms.Select(attrs={"class": "form-select"}),
            "observacion": forms.TextInput(attrs={"class": "form-control", "placeholder": "Opcional"}),
        }


class CompraForm(forms.ModelForm):
    class Meta:
        model = Compra
        fields = ["proveedor", "observacion"]
        widgets = {
            "proveedor": forms.Select(attrs={"class": "form-select"}),
            "observacion": forms.TextInput(attrs={"class": "form-control", "placeholder": "Opcional"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["proveedor"].queryset = Proveedor.objects.filter(activo=True)


class DetalleVentaForm(forms.ModelForm):
    class Meta:
        model = DetalleVenta
        fields = ["producto", "cantidad", "precio_unitario"]
        widgets = {
            "producto": forms.Select(attrs={"class": "form-select js-producto"}),
            "cantidad": forms.NumberInput(attrs={"class": "form-control js-cantidad", "min": 1, "step": 1}),
            "precio_unitario": forms.NumberInput(attrs={"class": "form-control js-precio", "min": "0.01", "step": "0.01"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["producto"].queryset = Producto.objects.filter(activo=True).select_related("marca")

    def clean_cantidad(self):
        cantidad = self.cleaned_data["cantidad"]
        if cantidad <= 0:
            raise forms.ValidationError("La cantidad debe ser positiva.")
        return cantidad

    def clean_precio_unitario(self):
        precio = self.cleaned_data["precio_unitario"]
        if precio <= 0:
            raise forms.ValidationError("El precio unitario debe ser mayor a cero.")
        return precio


class DetalleCompraForm(forms.ModelForm):
    class Meta:
        model = DetalleCompra
        fields = ["producto", "cantidad", "costo_unitario"]
        widgets = {
            "producto": forms.Select(attrs={"class": "form-select js-producto"}),
            "cantidad": forms.NumberInput(attrs={"class": "form-control js-cantidad", "min": 1, "step": 1}),
            "costo_unitario": forms.NumberInput(attrs={"class": "form-control js-precio", "min": "0.01", "step": "0.01"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["producto"].queryset = Producto.objects.filter(activo=True).select_related("marca")

    def clean_cantidad(self):
        cantidad = self.cleaned_data["cantidad"]
        if cantidad <= 0:
            raise forms.ValidationError("La cantidad debe ser positiva.")
        return cantidad

    def clean_costo_unitario(self):
        costo = self.cleaned_data["costo_unitario"]
        if costo <= 0:
            raise forms.ValidationError("El costo debe ser mayor a cero.")
        return costo


class DetallesObligatorios(BaseInlineFormSet):
    def clean(self):
        if any(self.errors):
            return
        usados = set()
        presentes = 0
        limite = Decimal("9999999999.99")
        total = Decimal("0.00")
        for form in self.forms:
            if not form.cleaned_data or form.cleaned_data.get("DELETE"):
                continue
            producto = form.cleaned_data.get("producto")
            if not producto:
                continue
            presentes += 1
            if producto.pk in usados:
                raise forms.ValidationError("No repitas el mismo producto; registra una sola fila por producto.")
            usados.add(producto.pk)
            valor = form.cleaned_data.get("precio_unitario") or form.cleaned_data.get("costo_unitario")
            cantidad = form.cleaned_data.get("cantidad")
            if valor is not None and cantidad is not None:
                subtotal = valor * cantidad
                if subtotal > limite:
                    raise forms.ValidationError("El subtotal supera el límite permitido (9.999.999.999,99).")
                total += subtotal
        if total > limite:
            raise forms.ValidationError("El total supera el límite permitido (9.999.999.999,99).")
        if presentes == 0:
            raise forms.ValidationError("Agrega al menos un producto con su cantidad y valor unitario.")
        super().clean()  # Mantiene las validaciones de unicidad propias de Django.


DetalleVentaFormSet = inlineformset_factory(
    Venta, DetalleVenta, form=DetalleVentaForm, formset=DetallesObligatorios,
    extra=2, min_num=1, validate_min=True, can_delete=True,
)
DetalleCompraFormSet = inlineformset_factory(
    Compra, DetalleCompra, form=DetalleCompraForm, formset=DetallesObligatorios,
    extra=2, min_num=1, validate_min=True, can_delete=True,
)
